package part2Q3;

public interface ShapeVisitable {

	public void accept(ShapeVisitor v);

}
