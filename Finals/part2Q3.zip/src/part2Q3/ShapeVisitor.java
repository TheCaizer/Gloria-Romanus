package part2Q3;

public interface ShapeVisitor {

	/*
	 * TODO Here, you need to add the required method signatures(s),
	 * to answer the question.
	 *
	 */

}
