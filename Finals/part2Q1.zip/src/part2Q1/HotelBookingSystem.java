package part2Q1;

public class HotelBookingSystem{

    public static void main(String []args){}
}
