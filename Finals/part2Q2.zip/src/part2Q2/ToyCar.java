package part2Q2;

public abstract class ToyCar extends Item {
}
