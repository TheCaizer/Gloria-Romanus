package part2Q3;

import java.awt.Color;

public class ShapeColourAreaVisitor implements ShapeVisitor {

    /*
     *
     * TODO In this class, you need to implement the required method(s), to
     * answer the question.
     *
     * You also need to implement the following constructor and declare
     * variables, if required.
     *
     */

    public ShapeColourAreaVisitor(Color colour) {

    }

    public double getTotalArea() {
        // TODO Implement this method as well
        return 0;
    }

}
