package part2Q3;

public class ShapeColourVisitor implements ShapeVisitor {

    /*
     *
     * TODO In this class, you need to implement the required method(s), to
     * answer the question.
     *
     */

}
